runtime per video [s] : 10.43 
CPU[1] / GPU[0] : 1
Extra Data [1] / No Extra Data [0] : 1
Other description: wangzhiyu918
